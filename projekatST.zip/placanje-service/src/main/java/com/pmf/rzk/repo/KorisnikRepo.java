package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StKorisnik;

public interface KorisnikRepo extends JpaRepository<StKorisnik, Integer> {

}
