package com.pmf.rzk.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pmf.rzk.model.StRacun;
import com.pmf.rzk.service.RacunService;

@RestController
public class RacunContr {
	
	@Autowired
	private RacunService rs;
	
	
	@PostMapping("/kreirajRacun/{iznos}/{idKorisnika}")
	public StRacun kreirajRacun(@PathVariable double iznos,@PathVariable Integer idKorisnika) {
		return rs.kreirajRacun(iznos, idKorisnika);
	}
	
	@PostMapping("/platidepozit")
    public StRacun platiDepozit(@RequestBody StRacun racun) {
        return rs.platiDepozit(racun.getStKorisnik().getKorisnikId(), racun.getIznos());
    }

}
