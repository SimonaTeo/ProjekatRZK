package com.pmf.rzk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacanjeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacanjeServiceApplication.class, args);
	}

}
