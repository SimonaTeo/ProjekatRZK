package com.pmf.rzk.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.model.StRacun;
import com.pmf.rzk.repo.KorisnikRepo;
import com.pmf.rzk.repo.RacunRepo;

@Service
public class RacunService {
	
	@Autowired
	private RacunRepo rr;
	
	@Autowired
	private KorisnikRepo kr;
	
	public StRacun kreirajRacun(double iznos,Integer korisnikId) {
		
		StKorisnik korisnik=kr.findById(korisnikId).get();
		StRacun racun = new StRacun();
	    racun.setIznos(iznos);
	    racun.setStKorisnik(korisnik);
	    
	    return rr.save(racun);
		
	}
	
	public StRacun platiDepozit(Integer korisnikId, Double iznosDepozita) {
        StRacun racun = rr.findByKor(korisnikId);
        
        if (racun != null) {
            if (racun.getIznos() >= iznosDepozita) {
                racun.setIznos(racun.getIznos() - iznosDepozita);
                return rr.save(racun);
            } else {
                throw new IllegalArgumentException("Nemate dovoljno sredstava na računu.");
            }
        } else {
            throw new RuntimeException("Račun nije pronađen za datog korisnika.");
        }
    }

}
