package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pmf.rzk.model.StRacun;

public interface RacunRepo extends JpaRepository<StRacun, Integer> {
	
	@Query("select r from StRacun r where r.stKorisnik.korisnikId= :korisnikId")
	public StRacun findByKor(@Param("korisnikId")Integer korisnikId);

}
