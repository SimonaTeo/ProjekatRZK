package com.pmf.rzk.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


/**
 * The persistent class for the stKorisnik database table.
 * 
 */
@Entity
@Table(name="stKorisnik")
@NamedQuery(name="StKorisnik.findAll", query="SELECT s FROM StKorisnik s")
public class StKorisnik implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int korisnikId;

	private String brojTelefona;

	@Temporal(TemporalType.DATE)
	private Date datumRodjenja;

	private String ime;

	private String jmbg;

	private String prezime;

	//bi-directional many-to-one association to StRacun
	@OneToMany(mappedBy="stKorisnik")
	@JsonIgnore
	private List<StRacun> stRacuns;

	public StKorisnik() {
	}

	public int getKorisnikId() {
		return this.korisnikId;
	}

	public void setKorisnikId(int korisnikId) {
		this.korisnikId = korisnikId;
	}

	public String getBrojTelefona() {
		return this.brojTelefona;
	}

	public void setBrojTelefona(String brojTelefona) {
		this.brojTelefona = brojTelefona;
	}

	public Date getDatumRodjenja() {
		return this.datumRodjenja;
	}

	public void setDatumRodjenja(Date datumRodjenja) {
		this.datumRodjenja = datumRodjenja;
	}

	public String getIme() {
		return this.ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getJmbg() {
		return this.jmbg;
	}

	public void setJmbg(String jmbg) {
		this.jmbg = jmbg;
	}

	public String getPrezime() {
		return this.prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public List<StRacun> getStRacuns() {
		return this.stRacuns;
	}

	public void setStRacuns(List<StRacun> stRacuns) {
		this.stRacuns = stRacuns;
	}

	public StRacun addStRacun(StRacun stRacun) {
		getStRacuns().add(stRacun);
		stRacun.setStKorisnik(this);

		return stRacun;
	}

	public StRacun removeStRacun(StRacun stRacun) {
		getStRacuns().remove(stRacun);
		stRacun.setStKorisnik(null);

		return stRacun;
	}

}