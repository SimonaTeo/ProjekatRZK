package com.pmf.rzk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacanjeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
