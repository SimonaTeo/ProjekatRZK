package com.pmf.rzk.servis;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.repo.KorisnikRepo;

@Service

public class KorisnikService {
	
	@Autowired
	private KorisnikRepo kr;
	
	
	public String registracijaKorisnika(String ime,String prezime,String jmbg,String brojTelefona,Date datumRodjenja) {
		
		StKorisnik korisnik=kr.findByImeAndPrezime(ime, prezime);
		String poruka;
		if(korisnik!=null) {
			poruka="Vec postoji korisnik sa ovim inicijalima.Neuspesna registracija";
		}else {
			StKorisnik novi=new StKorisnik();
			novi.setIme(ime);
			novi.setPrezime(prezime);
			novi.setJmbg(jmbg);
			novi.setBrojTelefona(brojTelefona);
			novi.setDatumRodjenja(datumRodjenja);
			kr.save(novi);
			poruka="Novi korisnik je kreiran.Uspesno ste se registrovali";
		}
		return poruka;
		
			
	}
	
	public StKorisnik proveriKorisnika(String ime,String prezime,Date datumRodjenja){
		
		StKorisnik kor=kr.findByImeAndPrezimeAndDatumRodjenja(ime, prezime, datumRodjenja);
		if(kor!=null) {
			return kor;
		}else {
			return null;
		
		}
	}
	
	

}
