package com.pmf.rzk.repo;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StKorisnik;

public interface KorisnikRepo extends JpaRepository<StKorisnik, Integer> {

	
	public StKorisnik findByImeAndPrezime(String ime,String prezime);
	
	public StKorisnik findByImeAndPrezimeAndDatumRodjenja(String ime,String prezime,Date datumRodjenja);
	
	
}
