package com.pmf.rzk.control;



import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.servis.KorisnikService;

@RestController
public class KorContr {
	
	@Autowired
	KorisnikService ks;
	
	@PostMapping("/registracija")
	public String registracijaKorisnika(@RequestBody StKorisnik korisnik) {
		return ks.registracijaKorisnika(korisnik.getIme(),korisnik.getPrezime(),korisnik.getJmbg(),korisnik.getBrojTelefona(),korisnik.getDatumRodjenja());
	}
	
	@GetMapping("/login/{ime}/{prezime}/{datumRodjenja}")
	public StKorisnik loginKorisnika(@PathVariable String ime,@PathVariable String prezime,@PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date datumRodjenja) {
		return ks.proveriKorisnika(ime, prezime, datumRodjenja);
	}

}
