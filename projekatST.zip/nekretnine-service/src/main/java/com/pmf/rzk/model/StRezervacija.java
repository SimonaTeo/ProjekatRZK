package com.pmf.rzk.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


/**
 * The persistent class for the stRezervacija database table.
 * 
 */
@Entity
@Table(name="stRezervacija")
@NamedQuery(name="StRezervacija.findAll", query="SELECT s FROM StRezervacija s")
public class StRezervacija implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idRezervacije;

	@Temporal(TemporalType.DATE)
	private Date datum;

	private String statusR;

	//bi-directional many-to-one association to StRezNekr
	@OneToMany(mappedBy="stRezervacija")
	@JsonIgnore
	private List<StRezNekr> stRezNekrs;

	//bi-directional many-to-one association to StKorisnik
	@ManyToOne
	@JoinColumn(name="korisnikId")
	private StKorisnik stKorisnik;

	public StRezervacija() {
	}

	public int getIdRezervacije() {
		return this.idRezervacije;
	}

	public void setIdRezervacije(int idRezervacije) {
		this.idRezervacije = idRezervacije;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public String getStatusR() {
		return this.statusR;
	}

	public void setStatusR(String statusR) {
		this.statusR = statusR;
	}

	public List<StRezNekr> getStRezNekrs() {
		return this.stRezNekrs;
	}

	public void setStRezNekrs(List<StRezNekr> stRezNekrs) {
		this.stRezNekrs = stRezNekrs;
	}

	public StRezNekr addStRezNekr(StRezNekr stRezNekr) {
		getStRezNekrs().add(stRezNekr);
		stRezNekr.setStRezervacija(this);

		return stRezNekr;
	}

	public StRezNekr removeStRezNekr(StRezNekr stRezNekr) {
		getStRezNekrs().remove(stRezNekr);
		stRezNekr.setStRezervacija(null);

		return stRezNekr;
	}

	public StKorisnik getStKorisnik() {
		return this.stKorisnik;
	}

	public void setStKorisnik(StKorisnik stKorisnik) {
		this.stKorisnik = stKorisnik;
	}

}