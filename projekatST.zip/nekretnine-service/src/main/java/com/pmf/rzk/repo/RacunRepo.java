package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StRacun;

public interface RacunRepo extends JpaRepository<StRacun, Integer> {

}
