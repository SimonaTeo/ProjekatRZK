package com.pmf.rzk.model;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the stRacun database table.
 * 
 */
@Entity
@Table(name="stRacun")
@NamedQuery(name="StRacun.findAll", query="SELECT s FROM StRacun s")
public class StRacun implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int racunId;

	private double iznos;

	//bi-directional many-to-one association to StKorisnik
	@ManyToOne
	@JoinColumn(name="korisnikId")
	private StKorisnik stKorisnik;

	public StRacun() {
	}

	public int getRacunId() {
		return this.racunId;
	}

	public void setRacunId(int racunId) {
		this.racunId = racunId;
	}

	public double getIznos() {
		return this.iznos;
	}

	public void setIznos(double iznos) {
		this.iznos = iznos;
	}

	public StKorisnik getStKorisnik() {
		return this.stKorisnik;
	}

	public void setStKorisnik(StKorisnik stKorisnik) {
		this.stKorisnik = stKorisnik;
	}

}