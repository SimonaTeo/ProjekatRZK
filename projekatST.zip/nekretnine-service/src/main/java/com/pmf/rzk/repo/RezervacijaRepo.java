package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StRezervacija;

public interface RezervacijaRepo extends JpaRepository<StRezervacija, Integer> {

}
