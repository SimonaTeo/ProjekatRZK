package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StKategorija;

public interface KategorijaRepo extends JpaRepository<StKategorija, Integer> {

	public StKategorija findByNaziv(String naziv);
}
