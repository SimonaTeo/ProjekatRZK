package com.pmf.rzk.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pmf.rzk.model.StKategorija;
import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.model.StNekretnina;
import com.pmf.rzk.model.StRezervacija;
import com.pmf.rzk.service.NekretnineService;

@RestController
public class NekretninaController {
	
	@Autowired
	private NekretnineService ns;
	
	@GetMapping("/nekretnine")
	public List<StNekretnina> vratiSveNekretnine(){
		return ns.sveNekretnine();
	}
	
	@GetMapping("/kategorijeNekretnina")
	public List<StKategorija> vratiSveKategorije(){
		return ns.sveKategorije();
	}
	
	@GetMapping("/nekretnine/{cena}")
	public List<StNekretnina> vratiSveNekretnineSaManjomCenom(@PathVariable Integer cena){
		return ns.NekrPoCeni(cena);
	}
	
	@GetMapping("/nekretnine1/{naziv}")
	public List<StNekretnina> vratiSveNekretninePoNazivu(@PathVariable String naziv){
		return ns.NekrPoKat(naziv);
	}
	
	@GetMapping("/nekretnine/{sprat}/{lokacija}")
	public List<StNekretnina> vratiSveSaSpratomILokacijom(@PathVariable int sprat,@PathVariable String lokacija){
		return ns.NekrSpLok(sprat, lokacija);
	}
	
	@GetMapping("/nekretnine/{sprat}/{lokacija}/{cena}/{kvadratura}/{sobnost}")
	public List<StNekretnina> vratiPoSvimKriterijumima(@PathVariable int sprat,@PathVariable String lokacija,@PathVariable int cena,@PathVariable int kvadratura,@PathVariable double sobnost){
		return ns.NekrSve(sprat, lokacija, cena, kvadratura, sobnost);
	}
	
	@PostMapping("/dodajnekretninu/{lokacija}/{sobnost}/{sprat}/{kvadratura}/{cena}/{stKategorija}")
	public String dodajNekretninu(@PathVariable String lokacija,@PathVariable double sobnost,@PathVariable int sprat,@PathVariable int kvadratura,@PathVariable double cena,@PathVariable String stKategorija) {
		StNekretnina nekr=ns.dodajNovuNekretninu(lokacija, sobnost, sprat, kvadratura, cena,stKategorija);
		String poruka="";
		if(nekr!=null) {
			poruka="Uspesno ste dodali novu nekretninu.";
		}else {
			poruka="Niste uspeli da dodate novu nekretninu.";
		}
		return poruka;
	
	}
	
	@PostMapping("/novaNekretnina")
	public String dodajNekr(@RequestBody StNekretnina nekretnina) {
		String poruka="";
		StNekretnina n=ns.dodajNekretninu(nekretnina);
		if(n!=null) {
			poruka="Nekretnina je uspesno dodata";
		}else {
			poruka="Nekretnina nije dodata.";
		}
		return poruka;
			
	}
	
	@PostMapping("/rezervacija/{idKorisnika}/{idNekretnine}")
	public String rezervacija(@PathVariable Integer idKorisnika,@PathVariable Integer idNekretnine) {
		String poruka="";
		StRezervacija nova=ns.rezervisi(idKorisnika,idNekretnine);
		if(nova!=null) {
			poruka="Nekretnina je rezervisana";
		}else {
			poruka="Nekretnina nije rezervisana";
		}
		return poruka;
	}
	
	@GetMapping("/prosecnaCenaNekrZaKvadraturu/{kvadratura}")
	public double prosecnaCenaStanovaZaKvadraturu(@PathVariable Integer kvadratura) {
		return ns.prosecnaCenaStanovaKvadrature(kvadratura);
	}
	
	@GetMapping("/ko-je-rezervisao/{idN}")
	public List<StKorisnik> vratiKorisnika(@PathVariable Integer idN){
		return ns.vratiKorKojiSuRezNekretninu(idN);
	}
	
	
	
}
