package com.pmf.rzk.model;

import java.io.Serializable;
import jakarta.persistence.*;
import java.util.Date;


/**
 * The persistent class for the stRezNekr database table.
 * 
 */
@Entity
@Table(name="stRezNekr")
@NamedQuery(name="StRezNekr.findAll", query="SELECT s FROM StRezNekr s")
public class StRezNekr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.DATE)
	private Date datum;

	private String statusRN;

	//bi-directional many-to-one association to StNekretnina
	@ManyToOne
	@JoinColumn(name="idNekr")
	private StNekretnina stNekretnina;

	//bi-directional many-to-one association to StRezervacija
	@ManyToOne
	@JoinColumn(name="idRez")
	private StRezervacija stRezervacija;

	public StRezNekr() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public String getStatusRN() {
		return this.statusRN;
	}

	public void setStatusRN(String statusRN) {
		this.statusRN = statusRN;
	}

	public StNekretnina getStNekretnina() {
		return this.stNekretnina;
	}

	public void setStNekretnina(StNekretnina stNekretnina) {
		this.stNekretnina = stNekretnina;
	}

	public StRezervacija getStRezervacija() {
		return this.stRezervacija;
	}

	public void setStRezervacija(StRezervacija stRezervacija) {
		this.stRezervacija = stRezervacija;
	}

}