package com.pmf.rzk.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


/**
 * The persistent class for the stNekretnina database table.
 * 
 */
@Entity
@Table(name="stNekretnina")
@NamedQuery(name="StNekretnina.findAll", query="SELECT s FROM StNekretnina s")
public class StNekretnina implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idN;

	private double cena;

	private int kvadratura;

	private String lokacija;

	private double sobnost;

	private int sprat;

	//bi-directional many-to-one association to StKategorija
	@ManyToOne
	@JoinColumn(name="idKategorije")
	private StKategorija stKategorija;

	//bi-directional many-to-one association to StRezNekr
	@OneToMany(mappedBy="stNekretnina")
	@JsonIgnore
	private List<StRezNekr> stRezNekrs;

	public StNekretnina() {
	}

	public int getIdN() {
		return this.idN;
	}

	public void setIdN(int idN) {
		this.idN = idN;
	}

	public double getCena() {
		return this.cena;
	}

	public void setCena(double cena) {
		this.cena = cena;
	}

	public int getKvadratura() {
		return this.kvadratura;
	}

	public void setKvadratura(int kvadratura) {
		this.kvadratura = kvadratura;
	}

	public String getLokacija() {
		return this.lokacija;
	}

	public void setLokacija(String lokacija) {
		this.lokacija = lokacija;
	}

	public double getSobnost() {
		return this.sobnost;
	}

	public void setSobnost(double sobnost) {
		this.sobnost = sobnost;
	}

	public int getSprat() {
		return this.sprat;
	}

	public void setSprat(int sprat) {
		this.sprat = sprat;
	}

	public StKategorija getStKategorija() {
		return this.stKategorija;
	}

	public void setStKategorija(StKategorija stKategorija) {
		this.stKategorija = stKategorija;
	}

	public List<StRezNekr> getStRezNekrs() {
		return this.stRezNekrs;
	}

	public void setStRezNekrs(List<StRezNekr> stRezNekrs) {
		this.stRezNekrs = stRezNekrs;
	}

	public StRezNekr addStRezNekr(StRezNekr stRezNekr) {
		getStRezNekrs().add(stRezNekr);
		stRezNekr.setStNekretnina(this);

		return stRezNekr;
	}

	public StRezNekr removeStRezNekr(StRezNekr stRezNekr) {
		getStRezNekrs().remove(stRezNekr);
		stRezNekr.setStNekretnina(null);

		return stRezNekr;
	}

}