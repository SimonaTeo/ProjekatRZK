package com.pmf.rzk.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.model.StNekretnina;

public interface KorisnikRepo extends JpaRepository<StKorisnik, Integer> {

	@Query("select k from StKorisnik k inner join k.stRezervacijas rez inner join rez.stRezNekrs rzn where rzn.stNekretnina= :nekretnina")
	public List<StKorisnik> findByNekretnina(@Param("nekretnina") StNekretnina nekretnina);
}
