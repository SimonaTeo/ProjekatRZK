package com.pmf.rzk.service;


import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pmf.rzk.model.StKategorija;
import com.pmf.rzk.model.StKorisnik;
import com.pmf.rzk.model.StNekretnina;
import com.pmf.rzk.model.StRezNekr;
import com.pmf.rzk.model.StRezervacija;
import com.pmf.rzk.repo.KategorijaRepo;
import com.pmf.rzk.repo.KorisnikRepo;
import com.pmf.rzk.repo.NekretninaRepo;
import com.pmf.rzk.repo.RezNekrRepo;
import com.pmf.rzk.repo.RezervacijaRepo;

@Service
public class NekretnineService {
	
	@Autowired
	private NekretninaRepo nekrRepo;

	
	@Autowired
	private KategorijaRepo kr;
	
	@Autowired
	private KorisnikRepo korR;
	
	@Autowired
	private RezervacijaRepo rezervacijaRepo;
	
	@Autowired
	private RezNekrRepo rnR;
	
	
	
	public List<StNekretnina> sveNekretnine(){
		return nekrRepo.findAll();
		
	}
	
	public List<StKategorija> sveKategorije(){
		return kr.findAll();
	}
	
	public List<StNekretnina> NekrPoCeni(int cena){
		return nekrRepo.findByCena(cena);
		
	}
	
	public List<StNekretnina> NekrPoKat(String naziv){
		return nekrRepo.findByNazivKat(naziv);
		
	}
	
	public List<StNekretnina> NekrSpLok(int sprat,String lokacija){
		return nekrRepo.findBySpratLokacija(sprat, lokacija);
	}
	
	public List<StNekretnina> NekrSve(int sprat,String lokacija,int cena,int kvadratura,double sobnost){
		return nekrRepo.findBySve(sprat, lokacija, cena, kvadratura, sobnost);
	}
	
	public StNekretnina dodajNovuNekretninu(String lokacija,double sobnost, int sprat,int kvadratura,double cena,String stKategorija) {
		
		StKategorija kat=kr.findByNaziv(stKategorija);
		StNekretnina nekretnina=new StNekretnina();
		nekretnina.setLokacija(lokacija);
		nekretnina.setSobnost(sobnost);
		nekretnina.setSprat(sprat);
		nekretnina.setKvadratura(kvadratura);
		nekretnina.setCena(cena);
		nekretnina.setStKategorija(kat);
		
		return nekrRepo.save(nekretnina);
		
	}
	
	public StNekretnina dodajNekretninu(StNekretnina n) {
		
		StNekretnina nekretnina=new StNekretnina();
		nekretnina.setLokacija(n.getLokacija());
		nekretnina.setSobnost(n.getSobnost());
		nekretnina.setSprat(n.getSprat());
		nekretnina.setKvadratura(n.getKvadratura());
		nekretnina.setCena(n.getCena());
		nekretnina.setStKategorija(n.getStKategorija());
		nekrRepo.save(nekretnina);
		return nekretnina;
	}
	
	public StRezervacija rezervisi(Integer idK,Integer idN) {
		
		StKorisnik novi=korR.findById(idK).get();
		StNekretnina nekr=nekrRepo.findById(idN).get();
		StRezervacija nova=new StRezervacija();
		nova.setStKorisnik(novi);
		nova.setStatusR("rezervisano");
		LocalDate now=LocalDate.now();
		Date date = Date.from(now.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		nova.setDatum(date);
		rezervacijaRepo.save(nova);
		
		StRezNekr rn=new StRezNekr();
		rn.setDatum(date);
		rn.setStNekretnina(nekr);
		rn.setStRezervacija(nova);
		rn.setStatusRN("aktivna");
		rnR.save(rn);
		
		return nova;
		
	}
	
	public double prosecnaCenaStanovaKvadrature(Integer kvadratura) {
		
        List<StNekretnina> stanovi = nekrRepo.findByKategorijaKvadratura("stan", kvadratura);
        
        double suma = 0;
        for (StNekretnina nekretnina : stanovi) {
            suma += nekretnina.getCena();
        }
        if (stanovi.size() > 0) {
            return suma / stanovi.size();
        } else {
            return 0; 
        }
    }
	
	public List<StKorisnik> vratiKorKojiSuRezNekretninu(Integer idN){
		StNekretnina nekr=nekrRepo.findById(idN).get();
		return korR.findByNekretnina(nekr);
	}
	
	

}
