package com.pmf.rzk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NekretnineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NekretnineServiceApplication.class, args);
	}

}
