package com.pmf.rzk.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pmf.rzk.model.StRezNekr;

public interface RezNekrRepo extends JpaRepository<StRezNekr, Integer> {

}
