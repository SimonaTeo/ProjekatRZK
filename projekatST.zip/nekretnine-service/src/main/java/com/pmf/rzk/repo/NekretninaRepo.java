package com.pmf.rzk.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pmf.rzk.model.StNekretnina;

public interface NekretninaRepo extends JpaRepository<StNekretnina, Integer> {
	
	@Query("select n from StNekretnina n where n.cena<= :cenaP ")
	public List<StNekretnina> findByCena(@Param ("cenaP") Integer cena);
	
	@Query("select n from StNekretnina n where n.stKategorija.naziv= :nazivK")
	public List<StNekretnina> findByNazivKat(@Param ("nazivK") String naziv);
	
	@Query("select n from StNekretnina n where n.sprat= :spratP and n.lokacija= :lokacija")
	public List<StNekretnina> findBySpratLokacija(@Param("spratP")Integer sprat, @Param("lokacija") String lokacija);
	
	@Query("select n from StNekretnina n where n.sprat= :spratP and n.lokacija= :lokacija and n.cena<= :cena and kvadratura= :kvadratura and sobnost= :sobnost")
	public List<StNekretnina> findBySve(@Param("spratP")Integer sprat, @Param("lokacija") String lokacija, @Param("cena") Integer cena,@Param("kvadratura") Integer kvadratura,
			@Param("sobnost") Double sobnost);

	@Query("select n from StNekretnina n where n.stKategorija.naziv= :nazivK and n.kvadratura= :kvadratura")
	public List<StNekretnina> findByKategorijaKvadratura(@Param("nazivK") String naziv,@Param("kvadratura") Integer kvadratura);
}
