package com.pmf.rzk.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


/**
 * The persistent class for the stKategorija database table.
 * 
 */
@Entity
@Table(name="stKategorija")
@NamedQuery(name="StKategorija.findAll", query="SELECT s FROM StKategorija s")
public class StKategorija implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idKategorije;

	private String naziv;

	//bi-directional many-to-one association to StNekretnina
	@OneToMany(mappedBy="stKategorija")
	@JsonIgnore
	private List<StNekretnina> stNekretninas;

	public StKategorija() {
	}

	public int getIdKategorije() {
		return this.idKategorije;
	}

	public void setIdKategorije(int idKategorije) {
		this.idKategorije = idKategorije;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public List<StNekretnina> getStNekretninas() {
		return this.stNekretninas;
	}

	public void setStNekretninas(List<StNekretnina> stNekretninas) {
		this.stNekretninas = stNekretninas;
	}

	public StNekretnina addStNekretnina(StNekretnina stNekretnina) {
		getStNekretninas().add(stNekretnina);
		stNekretnina.setStKategorija(this);

		return stNekretnina;
	}

	public StNekretnina removeStNekretnina(StNekretnina stNekretnina) {
		getStNekretninas().remove(stNekretnina);
		stNekretnina.setStKategorija(null);

		return stNekretnina;
	}

}