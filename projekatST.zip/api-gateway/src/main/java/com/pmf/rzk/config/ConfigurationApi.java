package com.pmf.rzk.config;


import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigurationApi {
	
	@Bean
	public RouteLocator gatewayRouter(RouteLocatorBuilder builder) {
		
		return builder.routes()
				.route(p->p.path("/registracija/**").uri("http://localhost:8002/korisnik-service"))
				.route(p->p.path("/login/**").uri("http://localhost:8002/korisnik-service"))
				.route(p->p.path("/rezervisiNekretninu/**").filters(f->f.rewritePath("/rezervisiNekretninu", "/rezervacijaNekretnine")).uri("lb://oglasnikNekretnina-service"))
				.route(p->p.path("/pretraziPoSvimKriterijumimaNekretnine/**").filters(f->f.rewritePath("/pretraziPoSvimKriterijumimaNekretnine","/pretraziNekretnine")).uri("lb://oglasnikNekretnina-service"))
				.route(p->p.path("/prikaziNekretnine/**").filters(f->f.rewritePath("/prikaziNekretnine", "/prikaziSveNekretnine")).uri("lb://oglasnikNekretnina-service"))
				.route(p->p.path("/dodajSvojuNekretninu/**").filters(f->f.rewritePath("/dodajSvojuNekretninu","/dodajNekretninu")).uri("lb://oglasnikNekretnina-service"))
				.build();
	}
	
	
	
	
}
