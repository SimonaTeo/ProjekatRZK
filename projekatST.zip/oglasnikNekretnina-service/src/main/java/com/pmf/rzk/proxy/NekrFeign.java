package com.pmf.rzk.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.pmf.rzk.beans.StNekretnina;


@FeignClient(name="nekretnine-service")//, url="localhost:8080")
public interface NekrFeign {
	
	@GetMapping("/nekretnine")
	public List<StNekretnina> vratiSveNekretnine();

	@GetMapping("/nekretnine/{sprat}/{lokacija}/{cena}/{kvadratura}/{sobnost}")
	public List<StNekretnina> pretraziNekretnine(@PathVariable int sprat,@PathVariable String lokacija,@PathVariable int cena,@PathVariable int kvadratura,@PathVariable double sobnost);
	
	@PostMapping("/novaNekretnina")
	public String dodajNekr(@RequestBody StNekretnina nekretnina);
	
	@PostMapping("/rezervacija/{idKorisnika}/{idNekretnine}")
	public String rezervacija(@PathVariable Integer idKorisnika,@PathVariable Integer idNekretnine);
}
