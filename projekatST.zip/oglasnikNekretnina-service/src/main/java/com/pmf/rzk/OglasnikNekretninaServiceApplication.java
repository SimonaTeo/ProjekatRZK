package com.pmf.rzk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class OglasnikNekretninaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OglasnikNekretninaServiceApplication.class, args);
	}

}
