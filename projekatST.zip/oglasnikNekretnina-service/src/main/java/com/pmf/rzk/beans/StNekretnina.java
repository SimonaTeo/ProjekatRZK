package com.pmf.rzk.beans;

public class StNekretnina {
	
	private int idN;
	private double cena;
	private int kvadratura;
	private String lokacija;
	private double sobnost;
	private int sprat;
	private StKategorija stKategorija;
	
	
	public StNekretnina() {
		super();
		// TODO Auto-generated constructor stub
	}


	public StNekretnina(int idN, double cena, int kvadratura, String lokacija, double sobnost, int sprat,
			StKategorija stKategorija) {
		super();
		this.idN = idN;
		this.cena = cena;
		this.kvadratura = kvadratura;
		this.lokacija = lokacija;
		this.sobnost = sobnost;
		this.sprat = sprat;
		this.stKategorija = stKategorija;
	}


	public int getIdN() {
		return idN;
	}


	public void setIdN(int idN) {
		this.idN = idN;
	}


	public double getCena() {
		return cena;
	}


	public void setCena(double cena) {
		this.cena = cena;
	}


	public int getKvadratura() {
		return kvadratura;
	}


	public void setKvadratura(int kvadratura) {
		this.kvadratura = kvadratura;
	}


	public String getLokacija() {
		return lokacija;
	}


	public void setLokacija(String lokacija) {
		this.lokacija = lokacija;
	}


	public double getSobnost() {
		return sobnost;
	}


	public void setSobnost(double sobnost) {
		this.sobnost = sobnost;
	}


	public int getSprat() {
		return sprat;
	}


	public void setSprat(int sprat) {
		this.sprat = sprat;
	}


	public StKategorija getStKategorija() {
		return stKategorija;
	}


	public void setStKategorija(StKategorija stKategorija) {
		this.stKategorija = stKategorija;
	}
	
	
	
	

}
