package com.pmf.rzk.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pmf.rzk.beans.StNekretnina;
import com.pmf.rzk.proxy.NekrFeign;

@RestController
public class Controller {
	
	@Autowired
	NekrFeign proxy;
	
	@GetMapping("/prikaziSveNekretnine")
	public List<StNekretnina> sveNekretnine(){
		return proxy.vratiSveNekretnine();
	}
	
	@GetMapping("/pretraziNekretnine/{sprat}/{lokacija}/{cena}/{kvadratura}/{sobnost}")
	public List<StNekretnina> pretraziNekretnine(@PathVariable int sprat,@PathVariable String lokacija,@PathVariable int cena,@PathVariable int kvadratura,@PathVariable double sobnost){
		
		return proxy.pretraziNekretnine(sprat, lokacija, cena, kvadratura, sobnost);
		
	}
	
	@PostMapping("/dodajNekretninu")
	public String dodajNekr(@RequestBody StNekretnina nekretnina) {
		
		return proxy.dodajNekr(nekretnina);
	}
	
	@PostMapping("/rezervacijaNekretnine/{idKorisnika}/{idNekretnine}")
	public String rezervacija(@PathVariable Integer idKorisnika,@PathVariable Integer idNekretnine) {
		
		return proxy.rezervacija(idKorisnika, idNekretnine);
	}
	

}
