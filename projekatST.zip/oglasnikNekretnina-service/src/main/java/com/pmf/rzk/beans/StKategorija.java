package com.pmf.rzk.beans;


public class StKategorija {
	
	private int idKategorije;
	private String naziv;
	

	public StKategorija() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StKategorija(int idKategorije, String naziv) {
		super();
		this.idKategorije = idKategorije;
		this.naziv = naziv;
	}

	public int getIdKategorije() {
		return idKategorije;
	}

	public void setIdKategorije(int idKategorije) {
		this.idKategorije = idKategorije;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	
	

}
