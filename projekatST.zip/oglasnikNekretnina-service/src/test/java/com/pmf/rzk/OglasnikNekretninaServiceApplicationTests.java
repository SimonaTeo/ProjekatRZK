package com.pmf.rzk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OglasnikNekretninaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
